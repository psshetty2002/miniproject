package ishahomeslibraries;

import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class DriverSetup {
	public static WebDriver driver;
	
	
	//Launch the application in the specified browser
	public static WebDriver startDriver(String browser) {
	
		int setup;

	 	
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
	 		System.out.println("Choose the browser \n1 for Chrome \n2 for Edge ");

	 		setup=sc.nextInt();

	 		if(setup==1){

	 			driver=new ChromeDriver();

	 		}

	 		else if(setup==2){

	 			driver=new EdgeDriver();

	 		}

	 		else {

	 			System.out.println("Enter a valid choise");

	 		}

	 		driver.get("https://ishahomes.com/");
	 		driver.manage().window().maximize();
	 		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				
		return driver;
		
	}
}