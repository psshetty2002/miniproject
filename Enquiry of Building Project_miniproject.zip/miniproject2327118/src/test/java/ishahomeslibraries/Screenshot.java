package ishahomeslibraries;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;

public class Screenshot {
	static WebDriver driver;

 //Capture the Screenshot of the result
	public static void takeScreenShot(WebDriver driver) throws IOException {
		File scrFile;
		scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(scrFile, new File("C:\\Users\\2327118\\eclipse-workspace\\miniproject2327118\\ScreenShots\\result.png"));
		System.out.println("Screenshot has been captured!");
	}
 
}
