package ishahomes;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ishacompleted {
	WebElement closeLivePop, enquirebtn, contactUsBtn;
	WebDriver driver;
	List<WebElement> countCompletedProjects, countCompleteProjects1;
	
	public ishacompleted(WebDriver driver) {
		this.driver=driver;
	}
	
	public void closeLiveChatPop()
	{
		closeLivePop = driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M1490 1245')]"));
		closeLivePop.click();
	}
		//Scroll
	public void ScrollDownToViewCompletedProjects()
	{
		JavascriptExecutor JSE = (JavascriptExecutor) driver;
		JSE.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	}
	//count total number of completed projects and print it to console
	public void countAllProjects(){
		countCompletedProjects = driver.findElements(By.xpath("//div[@class='elementor-element elementor-element-97dc427 elementor-widget elementor-widget-houzez_elementor_property-card-v6']//a[contains(text(), 'Isha')]"));
		System.out.println("Completed projects: "+countCompletedProjects.size());
	}
	
	public void scrollUpToFindFirstFive() 
	{
		JavascriptExecutor JSE = (JavascriptExecutor) driver;
		JSE.executeScript("window.scrollBy(0, -document.body.scrollHeight)");
	}
	
	//Display the names of first five completed projects to the console
	public void printFirstFiveProjects()
	{
		countCompleteProjects1 = driver.findElements(By.xpath("//div[@class='elementor-element elementor-element-97dc427 elementor-widget elementor-widget-houzez_elementor_property-card-v6']//a[contains(text(), 'Isha')]"));
		System.out.println("The first five completed projects: ");
		for(int i=0; i<5; i++) {
			System.out.println(countCompleteProjects1.get(i).getText());
		}
	}
		
	//Scroll down and click on “Enquire Now” button
	public void EnquiryNowbutton() {
		enquirebtn = driver.findElement(By.xpath("//a[normalize-space()='Enquire Now']"));
		enquirebtn.click();
	}
	
	public void ScrollDown1()
	{
		JavascriptExecutor JSE = (JavascriptExecutor) driver;
		JSE.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	}
	//Verify if “Contact Info” text is displayed on the page
	public void verifyContactUsElement()
	{
		String expected_result="";
		expected_result = driver.findElement(By.xpath("//span[contains(text(),'Contact Us')]")).getText();
		String actual_result = "Contact Us";
		if(expected_result.equalsIgnoreCase(actual_result))
		{
			System.out.println("Contact Us is displayed on the page");
		}
		else {
			System.out.println("Contact Us is not displayed on the page");
		}	
	}
	
	
	
	public void ClickOnContactUs()
	{
		contactUsBtn = driver.findElement(By.xpath("//span[normalize-space()='Contact Us']"));
		contactUsBtn.click();

	}

}
