package ishahomes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class homepage {
	WebElement minimizeElement, closeLivePop, completedproject;
	WebDriver driver;
	
	public homepage (WebDriver driver)
	{
		this.driver = driver;
	}
	//Handle any popups and the live chat that may appear
	public void minimizeLivesupport()
	{
		minimizeElement = driver.findElement(By.xpath("//a[@id='livchat_close']"));
		minimizeElement.click();
	}
	
	public void closeLiveChatPop()
	{
		closeLivePop = driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M1490 1245')]"));
		closeLivePop.click();
	}
	// Navigate to the “Completed Projects” page by clicking on “Completed Projects” menu link.
	public void clickOnCompleteProject() {
		completedproject = driver.findElement(By.xpath("//li[@id='menu-item-25810']//a[contains(@class,'nav-link')][normalize-space()='Completed Projects']"));
		completedproject.click();
	}
	

}