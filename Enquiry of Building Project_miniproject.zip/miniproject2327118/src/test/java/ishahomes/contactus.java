package ishahomes;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ishahomeslibraries.Screenshot;
 
public class contactus {
	public static WebElement closeLivePop, findEmail, email;
	WebDriver driver;
	
	public contactus(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void closeLiveChatPop()
	{
		closeLivePop = driver.findElement(By.xpath("//*[name()='path' and contains(@d,'M1490 1245')]"));
		closeLivePop.click();
	}
	
	//Read and display the email address for contact to console
	public void printEmail()
	{
		findEmail = driver.findElement(By.xpath("//a[normalize-space()='marketing@ishahomes.com']"));
		System.out.println("The Email is shown below:- "+findEmail.getText());
	}
	
	public void screenshotcapture() throws IOException
	{
		email = driver.findElement(By.xpath("//div[@class='elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-34d1fd3']//div[@class='elementor-widget-wrap elementor-element-populated']"));
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", email);
		Screenshot.takeScreenShot(driver);
	 }
	
}

