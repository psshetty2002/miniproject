package ishamain;


	import java.io.IOException;
	import org.openqa.selenium.WebDriver;
	import ishahomes.ishacompleted;
	import ishahomes.homepage;
	import ishahomes.contactus;
	import ishahomeslibraries.DriverSetup;

	public class ProjectMain extends DriverSetup {
		public static WebDriver driver; 
		public static String browser ;
		
		
		

		public static void main(String[] args) throws IOException, InterruptedException {
			// TODO Auto-generated method stub
			
			driver=DriverSetup.startDriver(browser);
			
			homepage home_page = new homepage(driver);
			home_page.minimizeLivesupport();
			home_page.closeLiveChatPop();
			home_page.minimizeLivesupport();			
			home_page.clickOnCompleteProject();
			
			ishacompleted completed_projects = new ishacompleted(driver);
			completed_projects.ScrollDownToViewCompletedProjects();
			completed_projects.countAllProjects();
			completed_projects.scrollUpToFindFirstFive();
			completed_projects.printFirstFiveProjects();
			completed_projects.EnquiryNowbutton();
			Thread.sleep(5000);
			
			completed_projects.ScrollDown1();
			completed_projects.verifyContactUsElement();
			completed_projects.ClickOnContactUs();
			
			
			
			
			contactus contact_us = new contactus(driver);
			contact_us.printEmail();
			
			contact_us.screenshotcapture();
			
			
			//Close the Browser
			driver.quit();

			
		}

	}
