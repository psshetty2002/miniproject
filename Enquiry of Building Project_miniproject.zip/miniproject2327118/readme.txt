1. Case Study: Enquiry of Building Project
 
 
2. Problem Statement:
 
Read the list of the completed projects by the builder 
 
2.1 Go to the Builders site
2.2 Display the list of the completed projects
2.3 Read names of the completed projects
2.4 Display Enquire Now Page
2.5 Verify if Contact Us text is displayed on the page
2.6 Read the email address to contact
2.7 Suggested site: https://ishahomes.com 
 
 
3. Detailed Description:
 
3.1 Launch the application in the specified browser
3.2 Handle any popups and the live chat that may appear
3.3 Maximize the browser and Navigate to the “Completed Projects” page by clicking on “Completed Projects” menu link.
3.4 It displays all the projects completed by Isha’s homes company.
3.5 Scroll down and count total number of completed projects and print it to console.
3.6 Display the names of first five completed projects to the console
3.7 Scroll down and click on “Enquire Now” button
3.8 Verify if “Contact Info” text is displayed on the page
3.9 Read and display the email address for contact to console
3.10 Capture the Screenshot of the result
3.11 Close the Browser
 
 
4. Key Automation Scope:   
 
4.1 Execute in different Browsers 
4.2 Handling pop ups
4.3 Extracting the number of completed projects with the builder 
4.4 Create common re-usable methods
4.5 Capturing screenshots

has context menu